import string

f = open('test.txt', 'r')
linesoutput = []
for line in f:
	l = str.split(line, ' ')
	linesoutput.append(l[1])

f = open('textoutput.txt', 'w')
for line in linesoutput:
	f.write("%s" % line)

